<?php
echo "creating symlink for easy usage...\n";
`ln -s /usr/local/php-packager/package.php /usr/bin/`;
